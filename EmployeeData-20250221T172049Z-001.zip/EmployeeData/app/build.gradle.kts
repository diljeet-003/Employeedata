plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.employeemanagementsystemproject"
    compileSdk = 35
   buildFeatures{
       viewBinding=true
   }

    defaultConfig {
        applicationId = "com.example.employeemanagementsystemproject"
        minSdk = 33
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.volley)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    dependencies {
        implementation ("androidx.appcompat:appcompat:1.6.1")
        implementation ("androidx.core:core-ktx:1.10.0") // Updated to a compatible version
        implementation ("com.google.android.material:material:1.9.0")// Updated to a compatible version
        implementation ("androidx.constraintlayout:constraintlayout:2.1.4")
        implementation ("com.android.volley:volley:1.2.1")
        implementation ("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.6.4")
        implementation ("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1")// Updated to a compatible version
        implementation ("androidx.lifecycle:lifecycle-livedata-ktx:2.6.1") // Updated to a compatible version
        testImplementation ("junit:junit:4.13.2")
        androidTestImplementation ("androidx.test.ext:junit:1.1.5")
        androidTestImplementation ("androidx.test.espresso:espresso-core:3.5.1")
    }
    androidTestImplementation(libs.androidx.espresso.core)
}